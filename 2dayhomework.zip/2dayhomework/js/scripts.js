var fristname = prompt ('What is your 1st name?');
console.log(fristname);
var lastname = prompt ('What is your last name?');
console.log(lastname);
alert (lastname);
var age = prompt("What Year is your Birthday?","");

alert (age);
if (age > 1997) {
    document.write("No beer for you!");


}
else { document.write("Have a beer");
};
